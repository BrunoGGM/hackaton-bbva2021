<?php

namespace App\Http\Controllers;

use App\Models\Chargeback;
use Illuminate\Http\Request;

class ChargebackController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Chargeback  $chargeback
     * @return \Illuminate\Http\Response
     */
    public function show(Chargeback $chargeback)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Chargeback  $chargeback
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Chargeback $chargeback)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Chargeback  $chargeback
     * @return \Illuminate\Http\Response
     */
    public function destroy(Chargeback $chargeback)
    {
        //
    }
}
