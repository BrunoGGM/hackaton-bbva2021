<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class ChargebackTypeSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
